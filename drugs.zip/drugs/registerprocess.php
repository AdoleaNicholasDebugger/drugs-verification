 
	<?php
include 'config/dbconfig.php'
?>
	 <?php
 error_reporting(E_ALL ^ E_NOTICE);
 
 $Firstname=$_POST['Firstname'];
 $Lastname=$_POST['Lastname'];
 $Email=$_POST['Email'];
 $Username=$_POST['Username'];
 $Password=$_POST['Password'];
  $Effects=0;
  $Advice=0;
 //Connects to your Database
 mysql_connect($dbhost,$dbuser,$dbpass) or die('cannot connect to the server'); 
mysql_select_db($dbname) or die('database selection problem');
$query="select * from registration ";
	
	

 $query="select * from patient";
$temp=1;

//random values
	$randomNumber1 = rand(1000, 9999);
	$randomNumber2 = rand(1000, 9999);
	$pin = "Drugs/".$randomNumber2.$randomNumber1;


 $result=mysql_query($query);
while ($row = mysql_fetch_array($result)) {
$temp=$temp+1;
}
$query="insert into patient
values('$temp','$pin','$Firstname','$Lastname', '$Email', '$Username','$Password','$Effects','$Advice')";
$result=mysql_query($query);

if ($result) {
?>
		<script>
		alert('Patient successfully registered with PID \n \n \t' + '<?php echo $pin;?>');
        window.location.href='index.php?success';
        </script>
		<?php
	}
	else
	{
		?>
		<script>
		alert('error registering patient');
        window.location.href='support.php?fail';
        </script>
		<?php
	}
	

 ?>
      