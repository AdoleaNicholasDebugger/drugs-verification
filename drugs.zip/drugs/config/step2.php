<html>
<head><title>Expert System</title>
</head>
</html>

 <?php

?>

<style type="text/css">
<!--
.style1 {color: #000099}
.style2 {
	color: #FF0000;
	font-weight: bold;
}
-->



</style>
<style type="text/css">
.pp {
border-bottom-style: dashed ; 
border-bottom-color: yellow; 
border-bottom-width: 5px; 
 border-top-style: double; 
border-top-color: purple; 
border-top-width: thick; 
 border-left-style: groove; 
border-left-color: green; 
border-left-width: 15px; 
border-bottom-style: ridge; 
border-bottom-color: yellow; 
border-bottom-width: 25px; 
}

</style>

<style type="text/css">
.styled-button-10 {
	background:#5CCD00;
	background:-moz-linear-gradient(top,#5CCD00 0%,#4AA400 100%);
	background:-webkit-gradient(linear,left top,left bottom,color-stop(0%,#5CCD00),color-stop(100%,#4AA400));
	background:-webkit-linear-gradient(top,#5CCD00 0%,#4AA400 100%);
	background:-o-linear-gradient(top,#5CCD00 0%,#4AA400 100%);
	background:-ms-linear-gradient(top,#5CCD00 0%,#4AA400 100%);
	background:linear-gradient(top,#5CCD00 0%,#4AA400 100%);
	filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#5CCD00',endColorstr='#4AA400',GradientType=0);
	padding:10px 15px;
	color:#fff;
	font-family:'Helvetica Neue',sans-serif;
	font-size:16px;
	border-radius:5px;
	-moz-border-radius:5px;
	-webkit-border-radius:5px;
	border:1px solid #459A00
}
</style>



<table width="800" border="0" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  <tr>
    <td height="47" colspan="2" valign="top"><!--DWLayoutEmptyCell-->&nbsp;</td>
  </tr>
  <tr>
    <td height="87" colspan="2" valign="top">

<div align="center">
  <?php

error_reporting(E_ALL ^ E_NOTICE);

	$db = @mysql_connect($_POST['db_host'] . ':' . $_POST['db_port'], $_POST['db_login'], $_POST['db_password']);
	if (!$db) {
		$errors[] = 'Unable to connect to database server.';
	} else {
		// check mysql version number
		$sql = "SELECT VERSION() AS version";
		$result = mysql_query($sql, $db);
		$row = mysql_fetch_assoc($result);
		if (version_compare($row['version'], '4.1.10', '>=') === FALSE) {
			$errors[] = 'MySQL version '.$row['version'].' was detected. AContent requires version 4.1.10 or later.';
		}

		if (!isset($errors)){
			if (!mysql_select_db($_POST['db_name'], $db)) {
				$sql = "CREATE DATABASE $_POST[db_name] CHARACTER SET utf8 COLLATE utf8_general_ci";
				$result = mysql_query($sql, $db);
				if (!$result) {
					$errors[] = 'Unable to select or create database <b>'.$_POST['db_name'].'</b>.';
				} else {
					echo '<font color="green">Database <b>'.$_POST['db_name'].'</b> created successfully.';
					mysql_select_db($_POST['db_name'], $db);
                                        
  
  mysql_query("CREATE TABLE patient(
 stid int(11) NOT NULL auto_increment,
 `pin` VARCHAR(45),
`Firstname` VARCHAR(45),
`Lastname` VARCHAR(45),
`Email` VARCHAR(45),
`Username` VARCHAR(45),
`Password` VARCHAR(45),
`Effects` VARCHAR(45),
`Advice` VARCHAR(45),
 PRIMARY KEY (`stid`,`Username`)
)")
 or die(mysql_error());
 
 
 
 
 
   mysql_query("CREATE TABLE trend(
`id` int(5) default NULL,
`category` varchar(19) ,
`count` int(19),
PRIMARY KEY(id)
)")
 or die(mysql_error());
 
 



   // put your code here 
				}
			} else {
				/* Check if the database that existed is in UTF-8, if not, ask for retry */
				$sql = "SHOW CREATE DATABASE $_POST[db_name]";
				$result = mysql_query($sql, $db);
				$row = mysql_fetch_assoc($result);
				
				if (!preg_match('/CHARACTER SET utf8/i', $row['Create Database'])){
					$errors[] = 'Database <b>'.$_POST['db_name'].'</b> is not in UTF8.  Please set the database character set to UTF8 before continuing by using the following query: ALTER DATABASE `'.$_POST['db_name'].'` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci.  To use ALTER DATABASE, you need the ALTER privilege on the database.';
				}
			}
		}

			
			
			
			}
		

	
?>

		
  <span class="style2"> Portal installation</span></div>
<form action="step2.php" method="post" name="form">
	<p align="center">
	  <input type="hidden" name="action" value="process" />
	  <input type="hidden" name="step" value="2" />
	  <input type="hidden" name="new_version" value="<?php echo $_POST['new_version']; ?>" />
	</p>
	<div align="center">
	  <table width="65%" class="pp"  cellspacing="0" cellpadding="1" border="1" align="center">
	    <tr><td class="row1"><div class="required" title="Required Field"></div><b><label for="db"><font color="white"><b>Database Hostname:</b></font></label></b><br />
	      Hostname of the database server. Default: <kbd>localhost</kbd></td>
		    <td class="row1" valign="middle"><input type="text" name="db_host" id="db" value="<?php if (!empty($_POST['db_host'])) { echo stripslashes(htmlspecialchars($_POST['db_host'])); } else { echo 'localhost'; } ?>" class="formfield" /></td>
	    </tr>
	    <tr><td class="row1"><div class="required" title="Required Field"></div><b><label for="port"><font color="white">Database Port:</font></label></b><br />
	      The port to the database server. Default: <kbd>3306</kbd></td>
		    <td class="row1"><input type="text" name="db_port" id="port" value="<?php if (!empty($_POST['db_port'])) { echo stripslashes(htmlspecialchars($_POST['db_port'])); } else { echo '3306'; } ?>" class="formfield" /></td>
	    </tr>
	    <tr><td class="row1"><div class="required" title="Required Field"></div><b><label for="username"><font color="white">Database Username:</font></label></b><br />
	      The username to the database server.</td>
		    <td class="row1"><input type="text" name="db_login" id="username" value="<?php echo stripslashes(htmlspecialchars($_POST['db_login'])); ?>" class="formfield" /></td>
	    </tr>
	    <tr><td class="row1"><div class="required" title="Required Field"></div><b><label for="pass"><font color="white">Database Password:</font></label></b><br />
	      The password to the database server.</td>
		    <td class="row1"><input type="text" name="db_password" id="pass" value="<?php echo stripslashes(htmlspecialchars($_POST['db_password'])); ?>" class="formfield" /></td>
	    </tr>
	    <tr><td class="row1"><div class="required" title="Required Field"></div><b><label for="name"><font color="white">Database Name:</font></label></b><br />
	      The name of the database to use. It will be created if it does not exist.<br /><kbd></kbd></td>
		    <td class="row1"><input type="text" name="db_name" id="name" value="<?php if (!empty($_POST['db_name'])) { echo stripslashes(htmlspecialchars($_POST['db_name'])); } else { echo 'Drugs'; } ?>" class="formfield" /></td>
	    </tr>
	    </table>
	  <br />
	  <br />
	  <span class="style1"> Stage 2/3</span></div>
	  
	   <?php

error_reporting(E_ALL ^ E_NOTICE);


if (isset($_POST['submit'])) {
	if ($_POST['submit'] == 'create') {
		unset($_POST['submit']);
		 
	} 
}


?>
                    <p align="center"><a href="step1.php" class="style14"></a>
                      <input type="submit" class="styled-button-10" value="create" name="submit" />
                      <a href="http://localhost/drugs" class="style14">Next</a>
                      </div>
                    
                    
                  </form></td>
      <td width="15">&nbsp;</td>
      </tr>
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            <!--DWLayoutEmptyCell-->&nbsp;
      </table></td>
      </tr>
        
        
        

  

  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
   <!--DWLayoutEmptyCell-->&nbsp;
      </table></td>
    </tr>
    <tr>
      <td height="4"></td>
      <td></td>
    </tr>
  </table>
</div>
</body>
</html>
