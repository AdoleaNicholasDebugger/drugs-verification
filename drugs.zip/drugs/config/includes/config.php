<?php
DEFINE('DATABASE','learn');
DEFINE('DBUSER','root');
DEFINE('DBPASS','don');
DEFINE('HOST','localhost');
include('includes/functions.php');
?>