<?php
 mysql_connect("localhost", "root", "don") or die(mysql_error()) ;
 mysql_select_db("drugs") or die(mysql_error()) ;

?>