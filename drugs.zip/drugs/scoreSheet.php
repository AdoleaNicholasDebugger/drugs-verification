<link rel="icon" type="image/png" sizes="16x16" href="../favicon-16x16.png">
<?php session_start();?>

 <?php include 'config/dbconfig.php';


if(!isset($_SESSION['username']))
{
header("Location:login.php");   
} 

 $visit=$_SESSION['username'];
  ?>


<?php


error_reporting(E_ALL ^ E_NOTICE);

mysql_connect($dbhost,$dbuser,$dbpass) or die('cannot connect to the server'); 
mysql_select_db($dbname) or die('database selection problem');


?>



<!DOCTYPE html>
<html lang="en"><head>
		<title></title>
		<meta charset="utf-8">
		
		<!--[if lt IE 9]>
		<script type="text/javascript" src="js/html5.js"></script>
		<link rel="stylesheet" href="css/ie.css" type="text/css" media="all">
		<![endif]-->
		<!--[if lt IE 7]>
			<div style=' clear: both; text-align:center; position: relative;'>
				<a href="http://windows.microsoft.com/en-US/internet-explorer/products/ie/home?ocid=ie6_countdown_bannercode"><img src="http://storage.ie6countdown.com/assets/100/images/banners/warning_bar_0000_us.jpg" border="0" height="42" width="820" alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today." /></a>
			</div>
		<![endif]-->
	    <style type="text/css">
<!--
.style1 {
	color: #330000;
	font-weight: bold;
	font-size: 36px;
}
.style7 {color: #FF0033}
.style10 {color: #990000; font-weight: bold; font-size: 36px; }
-->
        </style>
</head>
	<body id="page5">
	<script type="text/javascript"> Cufon.now(); </script>
	    <table width="1096" border="0" cellpadding="0" cellspacing="0">
	      <!--DWLayoutDefaultTable-->
	      <tr>
	        <td width="201" height="44"></td>
            <td width="27"></td>
            <td width="116">&nbsp;</td>
            <td colspan="10" valign="top"><div align="center"><span class="style10">Drug Addictions Expert System </span></div></td>
            <td width="29">&nbsp;</td>
            <td width="92">&nbsp;</td>
            <td width="82"></td>
	      </tr>
	      <tr>
	        <td height="38"></td>
	        <td></td>
	        <td>&nbsp;</td>
	        <td width="71">&nbsp;</td>
	        <td width="15">&nbsp;</td>
	        <td width="14">&nbsp;</td>
	        <td width="53">&nbsp;</td>
	        <td width="205">&nbsp;</td>
	        <td width="20">&nbsp;</td>
	        <td width="15">&nbsp;</td>
	        <td width="59">&nbsp;</td>
	        <td width="39">&nbsp;</td>
	        <td width="58">&nbsp;</td>
	        <td>&nbsp;</td>
	        <td>&nbsp;</td>
	        <td></td>
          </tr>
	      <tr>
	        <td height="21"></td>
	        <td colspan="14" valign="top" bgcolor="#000000"><!--DWLayoutEmptyCell-->&nbsp;</td>
            <td></td>
	      </tr>
	      <tr>
	        <td height="43"></td>
	        <td colspan="14" valign="top" bgcolor="#FFFFFF"><div align="center"><span class="style1">Diagnosis and Advice  sheet <a href="logout.php"></a></span></div></td>
            <td></td>
	      </tr>
	      <tr>
	        <td height="19"></td>
	        <td colspan="14" valign="top" bgcolor="#000000"><!--DWLayoutEmptyCell-->&nbsp;</td>
	        <td></td>
	      </tr>
	      
	      
	      
	      <tr>
	        <td height="19"></td>
	        <td rowspan="2" valign="top" bgcolor="#FFFFFF"><p><a href="../../registration/index.html"><img src="images/adminsession.png" width="19" height="18"></a>
			
			</p></td>
	        <td colspan="2" valign="top" bgcolor="#FFFFFF"><span class="style7">Patient </span> </td>
	        <td></td>
	        <td rowspan="5" valign="top" bgcolor="#CCCCCC"><!--DWLayoutEmptyCell-->&nbsp;</td>
	        <td>&nbsp;</td>
	        <td rowspan="3" valign="top" bgcolor="#FFFFFF"><span class="style7"><a href="../../registration/index.html"><img src="images/adminsession.png" alt="N" width="19" height="18"></a>Diagnosis </span></td>
	        <td>&nbsp;</td>
	        <td rowspan="6" valign="top" bgcolor="#CCCCCC"><!--DWLayoutEmptyCell-->&nbsp;</td>
	        <td>&nbsp;</td>
	        <td colspan="4" rowspan="3" valign="top" bgcolor="#FFFFFF"> <span class="style7"><a href="../../registration/index.html"><img src="images/adminsession.png" alt="J" width="19" height="18"></a>Advice</span> </td>
            <td></td>
	      </tr>
	      <tr>
	        <td height="3"></td>
	        <td></td>
	        <td></td>
	        <td></td>
	        <td></td>
	        <td></td>
	        <td></td>
	        <td></td>
          </tr>
	      <tr>
	        <td height="4"></td>
	        <td></td>
	        <td></td>
	        <td></td>
	        <td></td>
	        <td></td>
	        <td></td>
	        <td></td>
	        <td></td>
          </tr>
	      <tr>
	        <td height="16"></td>
	        <td></td>
	        <td></td>
	        <td></td>
	        <td></td>
	        <td></td>
	        <td></td>
	        <td></td>
	        <td></td>
	        <td></td>
	        <td></td>
	        <td></td>
	        <td></td>
	        <td></td>
          </tr>
	      <tr>
	        <td height="189"></td>
	        <td></td>
	        <td colspan="2" rowspan="2" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">
	          <!--DWLayoutTable-->
	          <?php
	
	error_reporting(E_ALL ^ E_NOTICE);
	


 
	$sql="SELECT * from patient WHERE pin = '".$visit."'";
	$result_set=mysql_query($sql);
	
	while($row=mysql_fetch_array($result_set))
	
	
	{
	$Firstname = $row["Firstname"]; 
		?>
		
        <tr>
		<td><?php echo $row['Firstname'] ?></td>
        </tr>
        <?php
	}
	?>
	          <tr>
	            <td width="187" height="154">&nbsp;</td>
              </tr>
            </table></td>
	        <td></td>
	        <td>&nbsp;</td>
	        <td rowspan="2" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">
	          	          <?php
	
	error_reporting(E_ALL ^ E_NOTICE);
	


 
$sql="SELECT * from patient WHERE pin = '".$visit."'";
	$result_set=mysql_query($sql);
	
	while($row=mysql_fetch_array($result_set))
	
	
	{
	$Effects = $row["Effects"]; 
		?>
		
        <tr>
		<font color="#000066"> <?php echo $row['pin'] ?>
<hr/>
       <td bgcolor="#FFCC66"><?php echo $row['Effects'] ?></td>

        </tr>
        <?php
	}
	?>
	   
	          <tr>
	            <td width="205" height="172">&nbsp;</td>
              </tr>
	          </table>	        </td>
	        <td></td>
	        <td></td>
	        <td colspan="4" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">
	         	          <?php
	
	error_reporting(E_ALL ^ E_NOTICE);
	


 
	$sql="SELECT * from patient WHERE pin = '".$visit."'";

	$result_set=mysql_query($sql);
	
	while($row=mysql_fetch_array($result_set))
	
	
	{
	$Advice = $row["Advice"]; 
		?>
		
        <tr>
        <td bgcolor="#FFFF66"><?php echo $row['Advice'] ?></td>
		
        </tr>
        <?php
	}
	?>
	   
	          <tr>
	            <td width="218" height="171">&nbsp;</td>
              </tr>
            </table></td>
	        <td></td>
          </tr>
	      <tr>
	        <td height="1"></td>
	        <td></td>
	        <td></td>
	        <td></td>
	        <td></td>
	        <td></td>
	        <td></td>
	        <td></td>
	        <td></td>
	        <td></td>
	        <td></td>
	        <td></td>
          </tr>
	      
	      
	      <tr>
	        <td height="19"></td>
	        <td colspan="14" valign="top" bgcolor="#000000"><!--DWLayoutEmptyCell-->&nbsp;</td>
	        <td></td>
          </tr>
	      <tr>
	        <td height="1"></td>
	        <td></td>
	        <td></td>
	        <td></td>
	        <td></td>
	        <td></td>
	        <td></td>
	        <td></td>
	        <td></td>
	        <td></td>
	        <td></td>
	        <td></td>
	        <td></td>
	        <td></td>
	        <td rowspan="2" valign="top" bgcolor="#FFCCFF"><p align='RIGHT'><a href='#' onclick='window.print()'>Print Result</a></p></td>
	        <td></td>
          <tr>
            <td height="19"></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td colspan="2" valign="top"><a href="index.php">Home</a></td>
            <td></td>
    </table>
	
</body>
</html>
