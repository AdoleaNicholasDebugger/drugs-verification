<?php
include 'config/dbconfig.php';
?>

<?php session_start();?>

 <?php 

if(!isset($_SESSION['username']))
{
header("Location:index.php");   
} 

 $visit=$_SESSION['username'];
 
 $quer=$visit;

  ?>






	<?php
	error_reporting(E_ALL ^ E_NOTICE);

	
$Agitation=$_POST['P01'];
$Anxiety=$_POST['P02'];
$BadBreath=$_POST['P03'];
 $Confusion=$_POST['P04'];
 $Constipation=$_POST['P05'];
 $Constrictedpupils=$_POST['P06'];
 $Dilatedpupils=$_POST['P07'];
 $Depressed=$_POST['P08'];
 $Drowsiness=$_POST['P09'];
 $Euphoria=$_POST['P10'];
  $Excitation=$_POST['P11'];
  $Hallucinations=$_POST['P12'];
 $Impairedjudgement=$_POST['P13'];
  $Incoordination=$_POST['P14'];
 $Increasedpupil=$_POST['P15'];
 $Insomnia=$_POST['P16'];
 $Lethargy=$_POST['P17'];
 $Nausea=$_POST['P18'];
 $Paranoia=$_POST['P19'];
 $Shallowrespiration=$_POST['P20'];
 $Slowedbreathing=$_POST['P21'];
  $Slurredspeech=$_POST['P22'];
 $Sweating=$_POST['P23'];
 $Talkativeness=$_POST['P24'];
 $Tremors=$_POST['P25'];
 $Vomiting=$_POST['P26'];
 $Weightloss=$_POST['P27'];
  $Drylips=$_POST['P28'];
 //-------------------------------------------Rule 1



mysql_connect($dbhost,$dbuser,$dbpass) or die('cannot connect to the server'); 
mysql_select_db($dbname) or die('database selection problem');

   
   $EFFECT="Resultant EFFECT may be STIMULANTS";
$Advice="Decide to make a change by building a meaningful drug-free life. Your health is not stable, think about how to stop taking drugs to improve it. Because your heart, respiratory, nervous, and digestive systems are at risk";

$usql="update patient set Effects='$EFFECT', Advice='$Advice' where pin ='$quer'";

	//echo $usql."<br>";
mysql_query($usql);
		
	


echo $quer;
?>
	