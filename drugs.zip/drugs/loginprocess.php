<link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png">
<?php
include 'config/dbconfig.php';
?>


<?php
error_reporting(E_ALL ^ E_NOTICE);
	session_start();
	
	
 $username=($_POST['username']);


if(isset($_POST['username']))
{
     $_SESSION['username'] = $_POST['username'];
	  $visit=$_SESSION['username'];
}


if (isset( $username ) ){



    // Connect to MySQL


    mysql_connect( $dbhost, $dbuser, $dbpass)

        or die ( 'Unable to connect to server. (hopealive)' );


    // Select database on MySQL server

if(isset($_POST['username']))
{
     $_SESSION['username'] = ($_POST['username']);
}

   	mysql_select_db($dbname )

        or die ( 'Unable to select database.(hopealive)' );



    // Formulate the query



    $sql="SELECT * FROM patient WHERE pin = '".$username."'";







    // Execute the query and put results in $result



    $result = mysql_query( $sql )

        or die ( 'Unable to execute query.' );



    // Get number of rows in $result.



    $num = mysql_numrows( $result );







    if ( $num == 1 ) {





        $auth = true;







		$row=mysql_fetch_row($result);



			$usero=$row[4];

			$passo=$row[5];

			







		setcookie("user","");

		setcookie("pass","");

		setcookie("pass",$passo);

		setcookie("user",$usero);

		











    }



}



if ( ! $auth ) {

?>
		<script>
		alert('wrong Patient ID');
        window.location.href='index.php';
        </script>
		<?php



} else {





  

header("Location:expert.php");





}

?>
