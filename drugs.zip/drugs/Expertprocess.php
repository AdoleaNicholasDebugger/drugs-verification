<?php
include 'config/dbconfig.php';
?>

<?php session_start();?>

 <?php 

if(!isset($_SESSION['username']))
{
header("Location:index.php");   
} 

 $visit=$_SESSION['username'];
 
 $quer=$visit;

  ?>






	<?php
	error_reporting(E_ALL ^ E_NOTICE);

	
$Agitation=$_POST['P01'];
$Anxiety=$_POST['P02'];
$BadBreath=$_POST['P03'];
 $Confusion=$_POST['P04'];
 $Constipation=$_POST['P05'];
 $Constrictedpupils=$_POST['P06'];
 $Dilatedpupils=$_POST['P07'];
 $Depressed=$_POST['P08'];
 $Drowsiness=$_POST['P09'];
 $Euphoria=$_POST['P10'];
  $Excitation=$_POST['P11'];
  $Hallucinations=$_POST['P12'];
 $Impairedjudgement=$_POST['P13'];
  $Incoordination=$_POST['P14'];
 $Increasedpupil=$_POST['P15'];
 $Insomnia=$_POST['P16'];
 $Lethargy=$_POST['P17'];
 $Nausea=$_POST['P18'];
 $Paranoia=$_POST['P19'];
 $Shallowrespiration=$_POST['P20'];
 $Slowedbreathing=$_POST['P21'];
  $Slurredspeech=$_POST['P22'];
 $Sweating=$_POST['P23'];
 $Talkativeness=$_POST['P24'];
 $Tremors=$_POST['P25'];
 $Vomiting=$_POST['P26'];
 $Weightloss=$_POST['P27'];
  $Drylips=$_POST['P28'];
 //-------------------------------------------Rule 1
if
(($Agitation=="1") && ($Anxiety=="1") && ($BadBreath=="1") && ($Confusion=="0") && ($Constipation=="0") && ($Constrictedpupils=="0") && ($Dilatedpupils=="1") && ($Depressed=="0") && ($Drowsiness=="0") && ($Euphoria=="1") && ($Excitation=="0") && ($Hallucinations=="1") && ($Impairedjudgement=="0") && ($Incoordination=="0") && ($Increasedpupil=="1") && ($Insomnia=="1") && ($Lethargy=="0") && ($Nausea=="0") && ($Paranoia=="1") && ($Shallowrespiration=="0") && ($Slowedbreathing=="0") && ($Slurredspeech=="0") && ($Sweating=="1") && ($Talkativeness=="1") && ($Tremors=="1") && ($Vomiting=="0") && ($Weightloss=="1") && ($Drylips=="1"))

{
mysql_connect($dbhost,$dbuser,$dbpass) or die('cannot connect to the server'); 
mysql_select_db($dbname) or die('database selection problem');

   
 $EFFECT1="Resultant EFFECT may be STIMULANTS";
$Advice1="Decide to make a change by building a meaningful drug-free life. Your health is not stable, think about how to stop taking drugs to improve it. Because your heart, respiratory, nervous, and digestive systems are at risk";

$usql="update patient set Effects='$EFFECT1', Advice='$Advice1' where pin ='$quer'";

$names = 0;
$result = mysql_query("SELECT count FROM trend where category ='Stimulant'");
 while($row = mysql_fetch_row($result)){
   $names =  $row [0];
   $names =  $names + 1;
   
   mysql_query("UPDATE trend SET count=$names WHERE category ='Stimulant' ");
   
   

	//echo $usql."<br>";
mysql_query($usql);
?>

		<script>
		alert('Resultant EFFECT may be STIMULANTS  \n .....Advice....... \n Decide to make a change by building a meaningful drug-free life. \nYour health is not stable, think about how to stop taking drugs to improve it.\n Because your heart, respiratory, nervous, and digestive systems are at risk');
        window.location.href='index.php?success';
        </script>
		<?php
}


  }



//-------------------------------------------Rule 2
if(($Agitation=="0") && ($Anxiety=="0") && ($BadBreath=="0") && ($Confusion=="0") && ($Constipation=="0") && ($Constrictedpupils=="0") && ($Dilatedpupils=="0") && ($Depressed=="0") && ($Drowsiness=="0") && ($Euphoria=="0") && ($Excitation=="0") && ($Hallucinations=="0") && ($Impairedjudgement=="0") && ($Incoordination=="0") && ($Increasedpupil=="0") && ($Insomnia=="0") && ($Lethargy=="0") && ($Nausea=="1") && ($Paranoia=="0") && ($Shallowrespiration=="0") && ($Slowedbreathing=="1") && ($Slurredspeech=="1") && ($Sweating=="0") && ($Talkativeness=="0") && ($Tremors=="0") && ($Vomiting=="1") && ($Weightloss=="0") && ($Drylips=="0"))


{
mysql_connect($dbhost,$dbuser,$dbpass) or die('cannot connect to the server'); 
mysql_select_db($dbname) or die('database selection problem');

$EFFECT2="Resultant EFFECT may be INHALANTS";
$Advice2="You are advised to reduce drug abuse.Explore your treatment options, do not let the body get worse.The identified effect  can result to memory loss or damage to liver, kidney, heart and brain";
   
   $usql="update patient set Effects='$EFFECT2', Advice='$Advice2' where pin ='$quer'";

$names = 0;
$result = mysql_query("SELECT count FROM trend where category ='inhalants'");
 while($row = mysql_fetch_row($result)){
   $names =  $row [0];
   $names =  $names + 1;
   
   mysql_query("UPDATE trend SET count=$names WHERE category ='inhalants' ");
   
   
	//echo $usql."<br>";
mysql_query($usql);

?>


		<script>
		alert('Resultant EFFECT may be INHALANTS \n  .....Advice.......  \n You are advised to reduce drug abuse. \n Explore your treatment options, do not let the body get worse. \n The identified effect  can result to memory loss or damage to liver, kidney, heart and brain');
        window.location.href='index.php?success';
        </script>
		<?php
}



 


}

//-------------------------------------------Rule 3
if(($Agitation=="0") && ($Anxiety=="0") && ($BadBreath=="0") && ($Confusion=="0") && ($Constipation=="1") && ($Constrictedpupils=="1") && ($Dilatedpupils=="0") && ($Depressed=="0") && ($Drowsiness=="1") && ($Euphoria=="1") && ($Excitation=="0") && ($Hallucinations=="0") && ($Impairedjudgement=="0") && ($Incoordination=="0") && ($Increasedpupil=="0") && ($Insomnia=="0") && ($Lethargy=="1") && ($Nausea=="1") && ($Paranoia=="0") && ($Shallowrespiration=="0") && ($Slowedbreathing=="0") && ($Slurredspeech=="0") && ($Sweating=="0") && ($Talkativeness=="0") && ($Tremors=="0") && ($Vomiting=="0") && ($Weightloss=="0") && ($Drylips=="0"))

{
mysql_connect($dbhost,$dbuser,$dbpass) or die('cannot connect to the server'); 
mysql_select_db($dbname) or die('database selection problem');

$EFFECT3="Resultant EFFECT may be Narcotics";
$Advice3="What are you waiting for? Do not wait until the body becomes worse and then regret it. Your body is deteriorating,can not stop using a drug to improve it?  If you do not stop drug abuse your life is at risk ";

 $usql="update patient set Effects='$EFFECT3', Advice='$Advice3' where pin ='$quer'";


$names = 0;
$result = mysql_query("SELECT count FROM trend where category ='Narcotics'");
 while($row = mysql_fetch_row($result)){
   $names =  $row [0];
   $names =  $names + 1;
   
   mysql_query("UPDATE trend SET count=$names WHERE category ='Narcotics' ");

	//echo $usql."<br>";
mysql_query($usql);



?>
		<script>
		alert('Resultant EFFECT may be Narcotics \n .....Advice.......\n What are you waiting for? Do not wait until the body becomes worse \n and then regret it. Your body is deteriorating, \n can not stop using a drug to improve it?  If you do not stop drug abuse your life is at risk ');
        window.location.href='index.php?success';
        </script>
		<?php
}


  }



//-------------------------------------------Rule 4
if(($Agitation=="0") && ($Anxiety=="0") && ($BadBreath=="0") && ($Confusion=="0") && ($Constipation=="0") && ($Constrictedpupils=="0") && ($Dilatedpupils=="0") && ($Depressed=="0") && ($Drowsiness=="0") && ($Euphoria=="1") && ($Excitation=="1") && ($Hallucinations=="1") && ($Impairedjudgement=="0") && ($Incoordination=="0") && ($Increasedpupil=="1") && ($Insomnia=="1") && ($Lethargy=="0") && ($Nausea=="0") && ($Paranoia=="0") && ($Shallowrespiration=="0") && ($Slowedbreathing=="0") && ($Slurredspeech=="0") && ($Sweating=="0") && ($Talkativeness=="0") && ($Tremors=="0") && ($Vomiting=="0") && ($Weightloss=="0") && ($Drylips=="0"))

{
mysql_connect($dbhost,$dbuser,$dbpass) or die('cannot connect to the server'); 
mysql_select_db($dbname) or die('database selection problem');

$EFFECT4="Resultant EFFECT may be Hallucinogens";
$Advice4="Your body is in a dangerous state;you must start to develop good health habits to improve. The identified effect can decrease your memory and concentration and can result in depression and lasting mental health problems";


 $usql="update patient set Effects='$EFFECT4', Advice='$Advice4' where pin ='$quer'";

$names = 0;
$result = mysql_query("SELECT count FROM trend where category ='Hallucinogens'");
 while($row = mysql_fetch_row($result)){
   $names =  $row [0];
   $names =  $names + 1;
   
   mysql_query("UPDATE trend SET count=$names WHERE category ='Hallucinogens' ");

	//echo $usql."<br>";
mysql_query($usql);

?>
		<script>
		alert('Resultant EFFECT may be Hallucinogens \n .....Advice.......\n Your body is in a dangerous state; \n you must start to develop good health habits to improve. \n The identified effect can decrease your memory and concentration and can result in depression and lasting mental health problems.');
        window.location.href='index.php?success';
        </script>
		<?php
}



  }


//-------------------------------------------Rule 5
if(($Agitation=="0") && ($Anxiety=="0") && ($BadBreath=="0") && ($Confusion=="0") && ($Constipation=="1") && ($Constrictedpupils=="1") && ($Dilatedpupils=="0") && ($Depressed=="0") && ($Drowsiness=="1") && ($Euphoria=="1") && ($Excitation=="0") && ($Hallucinations=="0") && ($Impairedjudgement=="0") && ($Incoordination=="0") && ($Increasedpupil=="0") && ($Insomnia=="0") && ($Lethargy=="1") && ($Nausea=="1") && ($Paranoia=="0") && ($Shallowrespiration=="0") && ($Slowedbreathing=="1") && ($Slurredspeech=="0") && ($Sweating=="0") && ($Talkativeness=="0") && ($Tremors=="0") && ($Vomiting=="0") && ($Weightloss=="0") && ($Drylips=="0"))


{
mysql_connect($dbhost,$dbuser,$dbpass) or die('cannot connect to the server'); 
mysql_select_db($dbname) or die('database selection problem');

$EFFECT5="Resultant EFFECT may be Cannabis";
$Advice5="You are strongly advised to see doctor.You need to reach out for support, do not feel that your body is healthy but it is not, your health is really bad";
$usql="update patient set Effects='$EFFECT5', Advice='$Advice5' where pin ='$quer'";


$names = 0;
$result = mysql_query("SELECT count FROM trend where category ='Cannabis'");
 while($row = mysql_fetch_row($result)){
   $names =  $row [0];
   $names =  $names + 1;
   
   mysql_query("UPDATE trend SET count=$names WHERE category ='Cannabis' ");


	//echo $usql."<br>";
mysql_query($usql);
?>
		<script>
		alert('then Resultant EFFECT may be Cannabis\n .....Advice.......\n You are strongly advised to see doctor. \n You need to reach out for support, do not feel \n that your body is healthy but it is not, your health is really bad. ');
        window.location.href='index.php?success';
        </script>
		<?php
}


 

  }


//-------------------------------------------Rule 6
if(($Agitation=="1") && ($Anxiety=="0") && ($BadBreath=="0") && ($Confusion=="0") && ($Constipation=="1") && ($Constrictedpupils=="0") && ($Dilatedpupils=="1") && ($Depressed=="1") && ($Drowsiness=="0") && ($Euphoria=="0") && ($Excitation=="0") && ($Hallucinations=="0") && ($Impairedjudgement=="1") && ($Incoordination=="1") && ($Increasedpupil=="0") && ($Insomnia=="0") && ($Lethargy=="0") && ($Nausea=="1") && ($Paranoia=="0") && ($Shallowrespiration=="1") && ($Slowedbreathing=="1") && ($Slurredspeech=="1") && ($Sweating=="0") && ($Talkativeness=="0") && ($Tremors=="1") && ($Vomiting=="1") && ($Weightloss=="0") && ($Drylips=="0"))


{
mysql_connect($dbhost,$dbuser,$dbpass) or die('cannot connect to the server'); 
mysql_select_db($dbname) or die('database selection problem');

$EFFECT6="Resultant EFFECT may be Depressants";
$Advice6="You need to withdraw from drug abuse to promote your health. Learn healthy ways to cope with stress. Physical activity and cognitive behavioural therapy can be effective treatments for your depression. I suggest that you go to the doctor for more advice, do not ignore this advice; this will change your life";
$usql="update patient set Effects='$EFFECT6', Advice='$Advice6' where pin ='$quer'";


 
$names = 0;
$result = mysql_query("SELECT count FROM trend where category ='Depressants'");
 while($row = mysql_fetch_row($result)){
   $names =  $row [0];
   $names =  $names + 1;
   
   mysql_query("UPDATE trend SET count=$names WHERE category ='Depressants' ");


	//echo $usql."<br>";
mysql_query($usql);

?>
		<script>
		alert('Resultant EFFECT may be Depressants \n ..Advice \n You need to withdraw from drug abuse to promote your health. Learn healthy ways to cope with stress. Physical activity and cognitive behavioural therapy can be effective treatments for your depression. I suggest that you go to the doctor for more advice, do not ignore this advice; this will change your life');
        window.location.href='index.php?success';
        </script>
		<?php
}


}
?>
		<script>
		alert('Select appropriate symptoms');
        window.location.href='expert.php?success';
        </script>
		<?php
?>
	