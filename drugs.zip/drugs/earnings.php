
<?php
include 'config/dbconfig.php';

error_reporting(E_ALL ^ E_NOTICE);


 //This gets the session

?>

      <?php session_start();?>

      <?php require("botdetect.php"); 

if(!isset($_SESSION['username']))
{
header("Location:capt.php");   
} 

 $visit=mysql_real_escape_string($_SESSION['username']);
  ?>


<?php
mysql_connect($dbhost,$dbuser,$dbpass) or die('cannot connect to the server'); 
mysql_select_db($dbname) or die('database selection problem');


$sql_query="SELECT * FROM transaction";
$result_set=mysql_query($sql_query);


if(isset($_GET['delete_id']))
{
 $sql_query="DELETE FROM transaction WHERE TID=".$_GET['delete_id'];
 mysql_query($sql_query);
 header("Location: dashboard.php");
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>PHP Delete Data With Javascript Confirmation - By Cleartuts</title>
<link rel="stylesheet" href="style.css" type="text/css" />
<script type="text/javascript">
function delete_id(id)
{
 if(confirm('Sure To Remove This Record ?'))
 {
  window.location.href='index.php?delete_id='+id;
 }
}
</script>


<style type="text/css">
<!--
.style1 {
	color: #FFFFFF;
	font-weight: bold;
}
.style2 {color: #FF0000}
-->
</style>
<table width="785" border="0" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  
  <tr>
    <td width="785" height="25" valign="top" bgcolor="#009933"><span class="style1">Earnings</span></td>
  </tr>
  <tr>
    <td height="107" valign="top">


      <!-- Javascript goes in the document HEAD -->
	  
      <script type="text/javascript">
function altRows(id){
	if(document.getElementsByTagName){  
		
		var table = document.getElementById(id);  
		var rows = table.getElementsByTagName("tr"); 
		 
		for(i = 0; i < rows.length; i++){          
			if(i % 2 == 0){
				rows[i].className = "evenrowcolor";
			}else{
				rows[i].className = "oddrowcolor";
			}      
		}
	}
}
window.onload=function(){
	altRows('alternatecolor');
}
      </script>

      <!-- CSS goes in the document HEAD or added to your external stylesheet -->
      <style type="text/css">
table.altrowstable {
	font-family: verdana,arial,sans-serif;
	font-size:11px;
	color:#333333;
	border-width: 1px;
	border-color: #a9c6c9;
	border-collapse: collapse;
}
table.altrowstable th {
	border-width: 1px;
	padding: 8px;
	border-style: solid;
	border-color: #a9c6c9;
}
table.altrowstable td {
	border-width: 1px;
	padding: 8px;
	border-style: solid;
	border-color: #a9c6c9;
}
.oddrowcolor{
	background-color:#d4e3e5;
}
.evenrowcolor{
	background-color:#c3dde0;
}
      </style>

      <!-- Table goes in the document BODY -->
      <table class="altrowstable" id="alternatecolor"  >
        <tr>
          <th>Details</th><th>Principal</th><th>Registration Bonus(20%)</th><th>Percentage Earned(40%)</th><th>Currently</th><th>Date created</th><th>Date Released</th>
    </tr>
        
        
        <?php
mysql_connect($dbhost,$dbuser,$dbpass) or die('cannot connect to the server'); 
mysql_select_db($dbname) or die('database selection problem');

$quer=mysql_real_escape_string($visit);
	
 
	$sql="SELECT * from transaction WHERE Email_address='$quer'";
	
	$result_set=mysql_query($sql);
	
	while($row=mysql_fetch_array($result_set))
	
	
	{
	$details = mysql_real_escape_string($row["details"]); 
	$principal = mysql_real_escape_string($row["principal"]); 
	$Registration_bonus = mysql_real_escape_string($row["Registration_bonus"]); 
	$Percentage_earn = mysql_real_escape_string($row["Percentage_earn"]); 
	$date_created = mysql_real_escape_string($row["date_created"]); 
	$date_release = mysql_real_escape_string($row["date_release"]); 
	
	$principa=number_format($principal);
	$Registration_bonu=number_format($Registration_bonus);
	$Percentage_ear=number_format($Percentage_earn);
	
	$Currently=$principal+$Registration_bonus+$Percentage_earn;
	$Currently=number_format($Currently);
		?>
        <tr>
          <td><?php echo mysql_real_escape_string($row['details']) ?></td>
          <td><?php echo mysql_real_escape_string($principa)?>HAI</td>
          <td><?php echo mysql_real_escape_string($Registration_bonu) ?>HAI</td>
          <td><?php echo mysql_real_escape_string($Percentage_ear) ?>HAI</td>
		   <td><span class="style2"><?php echo $Currently ?>HAI</span></td>
          <td><?php echo mysql_real_escape_string($row['date_created']) ?></td>
          <td><?php echo mysql_real_escape_string($row['date_release']) ?></td>
        </tr>
        <?php
	}
	?>
                  </table>
      </div>
&nbsp;</td>
  </tr>
  <tr>
    <td height="19">&nbsp;</td>
  </tr>
</table>
