<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Exper System</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="../css/style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="../css/coin-slider.css" />
<script type="text/javascript" src="../js/cufon-yui.js"></script>
<script type="text/javascript" src="../js/cufon-georgia.js"></script>
<script type="text/javascript" src="../js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="../js/script.js"></script>
<script type="text/javascript" src="../js/coin-slider.min.js"></script>
<style type="text/css">
<!--
.style1 {color: #000000}
.style2 {color: #000066}
.style3 {color: #990033}
.style5 {font-size: smaller}
-->
</style>
</head>
<body>
<div class="main">
  <div class="header">
    <div class="header_resize">
      <div class="logo">
        <h1><a href="index.html"><span class="style5">Drugs and Effects Diagnostic System</span><small></small></a></h1>
      </div>
      <div class="searchform">
        <form id="formsearch" name="formsearch" method="post" action="#">
          <span>
          <input name="editbox_search" class="editbox_search" id="editbox_search" maxlength="80" value="Search our ste:" type="text" />
          </span>
          <input name="button_search" src="../images/search.gif" class="button_search" type="image" />
        </form>
      </div>
      <div class="clr"></div>
      <div class="menu_nav">
        <ul>
           <li class="active"><a href="../index.php"><span>Home</span></a></li>
          <li><a href="../support.php"><span>Registration</span></a></li>
          <li><a href="../login.php"><span>Test & Diagnosis</span></a></li>
          <li><a href="../trender/chart_sample.php"><span>Trend</span></a></li>
          <li><a href="../scoresheet.php"><span>Print Report</span></a></li>
        </ul>
      </div>
      <div class="clr"></div>
      <div class="slider">
<table width="100%" border="0" cellpadding="0" cellspacing="0"  class="round"  bgcolor="#FFFFFF">
        <!--DWLayoutTable-->
        <tr>
          <td width="18" height="21"></td>
            <td width="123">&nbsp;</td>
            <td width="2">&nbsp;</td>
            <td width="201">&nbsp;</td>
            <td width="412"></td>
            <td width="204"></td>
        </tr>
        <tr>
          <td height="36"></td>
            <td colspan="3" valign="top"><span class="style1"><span class="style3">Drugs Trend Report </span><img src="../images/adminsession.png" width="32" height="32" /></span></td>
           
        </tr>
        
 
          <td colspan="2" rowspan="2" valign="top"><p>&nbsp;</p>
            
			<table width="825" border="0" cellpadding="0" cellspacing="0" align="center">
  <!--DWLayoutDefaultTable-->
  <tr>
    <td width="331" height="46">&nbsp;</td>
    <td width="494">&nbsp;</td>
  </tr>
  <tr>
    <td height="329">&nbsp;</td>
    <td valign="top"><link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png">

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">

<html>
<head>
<meta http-equiv="refresh" content="30"/>

  <title>Expert System</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"><style type="text/css">
<!--
body {
	background-color: #000000;
}
-->
</style></head>
<body>


  <div id="chart-container">FusionCharts will render here</div>
  <script src="fusionchart/jquery-2.1.4.js"></script>
  <script src="fusionchart/fusioncharts.js"></script>
  <script src="fusionchart/fusioncharts.charts.js"></script>
  <script src="fusionchart/themes/fusioncharts.theme.zune.js"></script>
  <script src="fusionchart/app.js"></script>
</body>
</html><!--DWLayoutEmptyCell-->&nbsp;</td>
  </tr>
</table>
     <p>&nbsp;   </p></td>
            <td></td>
        </tr>
        
      
            <td></td>
            <td></td>
        </tr>
        <tr>
          <td height="4"></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
        </tr>
      </table>
      </div>
        <div class="clr"></div>
    </div>
      <div class="clr"></div>
  </div>
</div>
<div class="footer">
    <div class="footer_resize">
      <p class="lf">&copy; Copyright</p>
      <div style="clear:both;"></div>
    </div>
</div>
</div>
</body>
</html>
