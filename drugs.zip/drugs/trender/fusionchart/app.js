

$(function(){
  $.ajax({

    url: 'http://localhost/drugs/trender/chart_data.php',
    type: 'GET',
    success : function(data) {
      chartData = data;
      var chartProperties = {
        "caption": "DRUGS ADDICTIONS",
        "xAxisName": "Drugs",
        "yAxisName": "Percentage",
        "rotatevalues": "1",
        "theme": "zune"
      };

      apiChart = new FusionCharts({
        type: 'pareto3d',
        renderAt: 'chart-container',
        width: '550',
        height: '350',
        dataFormat: 'json',
        dataSource: {
          "chart": chartProperties,
          "data": chartData
        }
      });
      apiChart.render();
    }
  });
});// JavaScript Document