<?php
include 'config/dbconfig.php';
?>

<?php session_start();?>

 <?php

if(!isset($_SESSION['username']))
{
header("Location:index.php");   
} 

 $visit=$_SESSION['username'];
  ?>




<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Exper System</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="css/coin-slider.css" />
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-georgia.js"></script>
<script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<script type="text/javascript" src="js/coin-slider.min.js"></script>
<style type="text/css">
<!--
.style1 {color: #000000}
.style5 {color: #990033; font-weight: bold; }
.style8 {color: #990000; font-weight: bold; }
.style10 {color: #0000FF; font-weight: bold; }
.style13 {
	font-size: 24px;
	color: #000033;
	font-weight: bold;
}
-->
</style>



<style type="text/css" >
form {
    width: 80%;
    margin: 0 auto;
}

label, input {
    /* in order to define widths */
    display: inline-block;
}

label {
    width: 110%;
    /* positions the label text beside the input */
    text-align: right;
}

label + input {
    width: 30%;
    /* large margin-right to force the next element to the new-line
       and margin-left to create a gutter between the label and input */
    margin: 0 30% 0 4%;
}

/* only the submit button is matched by this selector,
   but to be sure you could use an id or class for that button */
input + input {
    float: right;
}
​
.style2 {font-size: smaller}
</style>
</head>
<body>
<div class="main">
  <div class="header">
    <div class="header_resize">
      <div class="logo">
        <h1><a href="index.php"><span class="style2">Drugs and Effects Diagnostic System</span><small></small></a></h1>
      </div>
      <div class="searchform">
        <form id="formsearch" name="formsearch" method="post" action="#">
          <span>
          <input name="editbox_search" class="editbox_search" id="editbox_search" maxlength="80" value="Search our ste:" type="text" />
          </span>
          <input name="button_search" src="images/search.gif" class="button_search" type="image" />
        </form>
      </div>
      <div class="clr"></div>
      <div class="menu_nav">
        <ul>
          <li class="active"><a href="index.php"><span>Home</span></a></li>
          <li><a href="support.php">Registration</a></li>
          <li><a href="login.php"><span>Test & Diagnosis</span></a></li>
          <li><a href="trender/chart_sample.php"><span>Trend</span></a></li>
          <li><a href="scoresheet.php"><span>Print Report</span></a></li>
        </ul>
      </div>
      <div class="clr"></div>
      <div class="slider">
<table width="110%" border="0" cellpadding="8" cellspacing="1"  class="round"  bgcolor="#FFFFFF" align="center" >
        <!--DWLayoutTable-->
        <tr>
          <td width="7" height="21"></td>
            <td width="78">&nbsp;</td>
            <td width="31"></td>
            <td width="174"></td>
            <td width="27"></td>
          </tr>
        <tr>
          <td height="36"></td>
            <td colspan="2" valign="top"><span class="style1"><span class="style10">Expert System</span> <img src="images/adminsession.png" width="32" height="32" /></span></td>
		  <tr ></tr>
            <td>&nbsp;</td>
            <td class="style13">Symptoms</td>
          </tr>
        <tr>            <td>&nbsp;</td>

		</tr>
   
        
      
			
              <form id="form2" name="form2" method="post" action="Expertprocess.php" onSubmit='return validate();'>
			 
			 
  <tr>
    <td><span class="style5">
	
<label>Agitation<select name="P01" id="P01"> 
<option value="-">select</option>
<option value="0">0</option>
<option value="1">1</option>

      <br>
    </span></td>
   
  <td> <span class="style5">
  <label> Anxiety<select name="P02" id="P02">
<option value="-">select</option>
<option value="0">0</option>
<option value="1">1</option>
    <br>
  </span></td>
   <td> <span class="style5">
	<label>  Bad Breath <select name="P03" id="P03">
<option value="-">select</option>
<option value="0">0</option>
<option value="1">1</option>
     <br>
    </span></td>
  </tr>
 
   <tr>
     <td><span class="style5">
<label>Confusion <select name="P04" id="P04">
<option value="-">select</option>
<option value="0">0</option>
<option value="1">1</option><br>
     </span></td>
     <td> <span class="style5">
<label>Constipation <select name="P05" id="P05">
<option value="-">select</option>
<option value="0">0</option>
<option value="1">1</option       ><br>
     </span></td>
     <td><span class="style5">
<label>Constricted pupils <select name="P06" id="P06">
<option value="-">select</option>
<option value="0">0</option>
<option value="1">1</option><br>
     </span></td>
   </tr>
 
  <tr><td> <span class="style5">
  <label>Dilated pupils <select name="P07" id="P07">
<option value="-">select</option>
<option value="0">0</option>
<option value="1">1</option><br>
  </span></td>
    <td><span class="style5">
 <label>Depressed<select name="P08" id="P08">
<option value="-">select</option>
<option value="0">0</option>
<option value="1">1</option><br>
    </span></td>
    <td><span class="style5">
      <label>Drowsiness<select name="P09" id="P09">
<option value="-">select</option>
<option value="0">0</option>
<option value="1">1</option><br>
      
    </span></td>
  </tr>
   
   <tr><td> <span class="style5">
<label>Euphoria<select name="P10" id="P10">
<option value="-">select</option>
<option value="0">0</option>
<option value="1">1</option> <br>
   </span></td>
     <td><span class="style5">
<label>Excitation<select name="P11" id="P11">
<option value="-">select</option>
<option value="0">0</option>
<option value="1">1</option> <br>
     </span></td>
     <td><span class="style5">
<label>Hallucinations<select name="P12" id="P12">
<option value="-">select</option>
<option value="0">0</option>
<option value="1">1</option><br>
     </span></td>
   </tr>
  
   <tr><td> <span class="style5">
<label>Impaired judgement<select name="P13" id="P13">
<option value="-">select</option>
<option value="0">0</option>
<option value="1">1</option><br>
   </span></td>
     <td><span class="style5">
<label>Incoordination<select name="P14" id="P14">
<option value="-">select</option>
<option value="0">0</option>
<option value="1">1</option><br>
     </span></td>
     <td> <span class="style5">
 <label>Increased pupil<select name="P15" id="P15">
<option value="-">select</option>
<option value="0">0</option>
<option value="1">1</option> <br>
     </span></td>
   </tr>

<tr> <td> <span class="style5">
<label>Insomnia<select name="P16" id="P16">
<option value="-">select</option>
<option value="0">0</option>
<option value="1">1</option>  <br>
</span></td>
<td> <span class="style5">
<label>Lethargy<select name="P17" id="P17">
<option value="-">select</option>
<option value="0">0</option>
<option value="1">1</option>  <br>
  
</span></td>
 <td> <span class="style5">
<label>Nausea<select name="P18" id="P18">
<option value="-">select</option>
<option value="0">0</option>
<option value="1">1</option>    <br>
 </span></td>
</tr>
 
  <tr>
    <td><span class="style5">
<label>Paranoia<select name="P19" id="P19">
<option value="-">select</option>
<option value="0">0</option>
<option value="1">1</option>  <br>
    </span></td>
    <td>  <span class="style5">
<label>Shallow respiration<select name="P20" id="P20">
<option value="-">select</option>
<option value="0">0</option>
<option value="1">1</option><br>
    </span></td>
    <td> <span class="style5">
<label>Slowed breathing<select name="P21" id="P21">
<option value="-">select</option>
<option value="0">0</option>
<option value="1">1</option><br>
    </span></td>
  </tr>
 
 <tr> <td> <span class="style5">
<label>Slurred speech<select name="P22" id="P22">
<option value="-">select</option>
<option value="0">0</option>
<option value="1">1</option><br>
 </span></td>
  <td> <span class="style5">
<label>Sweating<select name="P23" id="P23">
<option value="-">select</option>
<option value="0">0</option>
<option value="1">1</option><br><br>
  </span></td>
 <td> <span class="style5">
<label>Talkativeness<select name="P24" id="P24">
<option value="-">select</option>
<option value="0">0</option>
<option value="1">1</option><br>
 </span></td>
 </tr>
 
   <tr><td> <span class="style8">
<label>Tremors<select name="P25" id="P25">
<option value="-">select</option>
<option value="0">0</option>
<option value="1">1</option><br>
   </span></td>
  <td><span class="style8">
<label>Vomiting<select name="P26" id="P26">
<option value="-">select</option>
<option value="0">0</option>
<option value="1">1</option>    <br>
  </span></td>
   <td><span class="style8">
   <label>   Weight loss<select name="P27" id="P27">
<option value="-">select</option>
<option value="0">0</option>
<option value="1">1</option>  
     <br>
   </span></td></tr>
   
   <tr><td><span class="style5">
    <label> Dry lips<select name="P28" id="P28">
<option value="-">select</option>
<option value="0">0</option>
<option value="1">1</option>
     </span><br></td>
   
 </td> <tr><td><input type="submit" value="Diagnose"></tr>
 
 
 

</form>

              <p>&nbsp;   </p></td>
            <td></td>
          </tr>
      </table>
      </div>
        <div class="clr"></div>
    </div>
      <div class="clr"></div>
  </div>
</div>
<div class="footer">
    <div class="footer_resize">
      <p class="lf">&copy; Copyright</p>
      <div style="clear:both;"></div>
    </div>
</div>
</div>
</body>
</html>
