<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Expert System</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="css/coin-slider.css" />
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-georgia.js"></script>
<script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<script type="text/javascript" src="js/coin-slider.min.js"></script>
<style type="text/css">
<!--
.style2 {font-size: smaller}
-->
</style>
</head>
<body>
<div class="main">
  <div class="header">
    <div class="header_resize">
      <div class="logo">
        <h1><a href="index.php"><span class="style2">Drugs and Effects Diagnostic System</span>  <small></small></a></h1>
</div>
      <div class="searchform">
        <form id="formsearch" name="formsearch" method="post" action="#">
          <span>
          <input name="editbox_search" class="editbox_search" id="editbox_search" maxlength="80" value="Search our ste:" type="text" />
          </span>
          <input name="button_search" src="images/search.gif" class="button_search" type="image" />
        </form>
      </div>
      <div class="clr"></div>
      <div class="menu_nav">
        <ul>
          <li class="active"><a href="index.php"><span>Home</span></a></li>
          <li><a href="support.php"><span>Registration</span></a></li>
          <li><a href="login.php"><span>Test & Diagnosis</span></a></li>
          <li><a href="trender/chart_sample.php"><span>Trend</span></a></li>
          <li><a href="scoresheet.php"><span>Print Report</span></a></li>
        </ul>
      </div>
      <div class="clr"></div>
      <!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<meta name="description" content="Made with WOW Slider - Create beautiful, responsive image sliders in a few clicks. Awesome skins and animations. Image carousel" />
	
	<!-- Start WOWSlider.com HEAD section --> <!-- add to the <head> of your page -->
	<link rel="stylesheet" type="text/css" href="engine1/style.css" />
	<script type="text/javascript" src="engine1/jquery.js"></script>
	<!-- End WOWSlider.com HEAD section -->

</head>
<body style="background-color:#d7d7d7;margin:auto">
	
	<!-- Start WOWSlider.com BODY section --> <!-- add to the <body> of your page -->
	<div id="wowslider-container1">
	<div class="ws_images"><ul>
		<li><img src="data1/images/a.jpg" alt="a" title="a" id="wows1_0"/></li>
		<li><img src="data1/images/b.jpg" alt="b" title="b" id="wows1_1"/></li>
		<li><img src="data1/images/c.jpg" alt="c" title="c" id="wows1_2"/></li>
		<li><img src="data1/images/d.jpg" alt="d" title="d" id="wows1_3"/></li>
		<li><img src="data1/images/e.jpg" alt="e" title="e" id="wows1_4"/></li>
		<li><img src="data1/images/f.jpg" alt="f" title="f" id="wows1_5"/></li>
		<li><img src="data1/images/g.jpg" alt="g" title="g" id="wows1_6"/></li>
		<li><a href="http://wowslider.com/vf"><img src="data1/images/h.jpg" alt="full screen slider" title="h" id="wows1_7"/></a></li>
		<li><img src="data1/images/i.jpg" alt="i" title="i" id="wows1_8"/></li>
	</ul></div>
	<div class="ws_bullets"><div>
		<a href="#" title="a"><img src="data1/tooltips/a.jpg" alt="a"/>1</a>
		<a href="#" title="b"><img src="data1/tooltips/b.jpg" alt="b"/>2</a>
		<a href="#" title="c"><img src="data1/tooltips/c.jpg" alt="c"/>3</a>
		<a href="#" title="d"><img src="data1/tooltips/d.jpg" alt="d"/>4</a>
		<a href="#" title="e"><img src="data1/tooltips/e.jpg" alt="e"/>5</a>
		<a href="#" title="f"><img src="data1/tooltips/f.jpg" alt="f"/>6</a>
		<a href="#" title="g"><img src="data1/tooltips/g.jpg" alt="g"/>7</a>
		<a href="#" title="h"><img src="data1/tooltips/h.jpg" alt="h"/>8</a>
		<a href="#" title="i"><img src="data1/tooltips/i.jpg" alt="i"/>9</a>
	</div></div><span class="wsl"><a href="http://wowslider.com/vu">image carousel</a> by WOWSlider.com v7.2</span>
	<div class="ws_shadow"></div>
	</div>	
	<script type="text/javascript" src="engine1/wowslider.js"></script>
	<script type="text/javascript" src="engine1/script.js"></script>
	<!-- End WOWSlider.com BODY section -->

</body>
</html>
      <div class="clr"></div>
    </div>
  </div>
  <div class="content">
    <div class="content_resize">
      <div class="mainbar">
        <div class="article">
          <h2><span>Risks of </span> Drug Abuse</h2>
          
          <div class="img"><img src="images/h.jpg" width="198" height="208" alt="" class="fl" /></div>
          <div class="post_content">
            <p align="justify"><font face="Courier New, Courier, monospace" color="#333333">Drug abuse carries with it a bevy of potential side effects, depending on the specific drug being used:

    Those abusing stimulants like cocaine or amphetamines may experience fatigue, depression, and lethargy as they come down from their highs.
    Individuals who abuse opiate drugs, such as heroin or prescription painkillers, may experience intestinal issues, muscle aches, and nervousness, per WebMD.

Perhaps the most serious risk of drug abuse is the potential to overdose.
​
In 2009, there were 4.6 million emergency room visits related to drug use, per the National Institute on Drug Abuse. While some of these visits were due to unfavorable reactions to drugs, roughly 45% of the visits involved drug abuse. The majority of the visits were due to the nonmedical use of prescription and over-the-counter drugs, including stimulants, opiates, and dietary supplements. Of illegal drugs that led to emergency room visits, cocaine was the most commonly abused, followed by heroin and stimulants.
​
Prompt medical attention can often save a life and limit the serious damage done; however, the best way to prevent an overdose is to get help. If drug abuse is an issue, it’s only a matter of time before addiction takes hold. It’s important to get help before an overdose or substantial long-term damage occurs</p>
          </div>
          <div class="clr"></div>
        </div>
       
          
        <p class="pages"><small>Page 1 of 2</small> <span>1</span> <a href="#">2</a> <a href="#">&raquo;</a></p>
      </div>
      <div class="sidebar">
        <div class="gadget">
          <p align="justify"><h2 class="star"><span>Treatment </span> Options</h2>
          <div class="clr"></div>
          <ul class="sb_menu"><font color="#333333">
            <li>1.A thorough mental and physical assessment.</a></li>
            <li>2.Detoxification</a></li>
            <li>3.Individual or group therapy.</a></li>
            <li>4.Participation in support groups.</a></li>
            <li>5.A comprehensive aftercare program.</a></li>
          
          </ul>
        </div>
        <div class="gadget">
          
          </ul>
        </div>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="fbg">
    <div class="fbg_resize">
      <div class="col c1">
        
       
       
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="footer">
    <div class="footer_resize">
      <p class="lf">&copy; Copyright <a href="#"></a>.</p>
      <div style="clear:both;"></div>
    </div>
  </div>
</div>
</html>
