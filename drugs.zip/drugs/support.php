<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Exper System</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="css/coin-slider.css" />
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-georgia.js"></script>
<script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<script type="text/javascript" src="js/coin-slider.min.js"></script>
<style type="text/css">
<!--
.style1 {color: #000000}
.style2 {color: #000066}
.style3 {color: #990033}
.style5 {font-size: smaller}
-->
</style>
</head>
<body>
<div class="main">
  <div class="header">
    <div class="header_resize">
      <div class="logo">
        <h1><a href="index.php"><span class="style5">Drugs and Effects Diagnostic System</span><small></small></a></h1>
      </div>
      <div class="searchform">
        <form id="formsearch" name="formsearch" method="post" action="#">
          <span>
          <input name="editbox_search" class="editbox_search" id="editbox_search" maxlength="80" value="Search our ste:" type="text" />
          </span>
          <input name="button_search" src="images/search.gif" class="button_search" type="image" />
        </form>
      </div>
      <div class="clr"></div>
      <div class="menu_nav">
        <ul>
           <li class="active"><a href="index.php"><span>Home</span></a></li>
          <li><a href="support.php"><span>Registration</span></a></li>
          <li><a href="login.php"><span>Test & Diagnosis</span></a></li>
          <li><a href="trender/chart_sample.php"><span>Trend</span></a></li>
          <li><a href="scoresheet.php"><span>Print Report</span></a></li>
        </ul>
      </div>
      <div class="clr"></div>
      <div class="slider">
<table width="100%" border="0" cellpadding="0" cellspacing="0"  class="round"  bgcolor="#FFFFFF">
        <!--DWLayoutTable-->
        <tr>
          <td width="18" height="21"></td>
            <td width="123">&nbsp;</td>
            <td width="2">&nbsp;</td>
            <td width="201">&nbsp;</td>
            <td width="412"></td>
            <td width="204"></td>
        </tr>
        <tr>
          <td height="36"></td>
            <td colspan="3" valign="top"><span class="style1"><span class="style3">SignUp</span> <img src="images/adminsession.png" width="32" height="32" /></span></td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>
        
   
        <tr>
          <td height="12"></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
        <tr>
          <td height="4"></td>
          <td></td>
          <td></td>
          <td colspan="2" rowspan="2" valign="top"><p>&nbsp;</p>
            <form id="form2" name="form2" method="post" action="registerprocess.php" onSubmit='return validate();'>
              <label>
                <input type="text" name="Firstname" required />
                </label>
              <span class="style3">
                *</span>
              <p>
                <label>
                  <input type="text" name="Lastname" required />
                  </label>
                <span class="style3">*</span></p>
                        <p>
                          <label>
                          <input type="text" name="Email" required />
                          </label>
                          <span class="style3">*</span></p>
                        <p>
                          <label>
                          <input type="text" name="Username" required />
                          </label>
                          <span class="style3">
                        *</span></p>
                        <p>
                          <label><select name="Birthday_day" id="Birthday_Day">
  <option value="-1">Day:</option>
  <option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
  <option value="5">5</option>
  <option value="6">6</option>
  <option value="7">7</option>
  <option value="8">8</option>
  <option value="9">9</option>
  <option value="10">10</option>
  <option value="11">11</option>
  <option value="12">12</option>
  <option value="13">13</option>
  <option value="14">14</option>
  <option value="15">15</option>
  <option value="16">16</option>
  <option value="17">17</option>
  <option value="18">18</option>
  <option value="19">19</option>
  <option value="20">20</option>
  <option value="21">21</option>
  <option value="22">22</option>
  <option value="23">23</option>
  <option value="24">24</option>
  <option value="25">25</option>
  <option value="26">26</option>
  <option value="27">27</option>
  <option value="28">28</option>
  <option value="29">29</option>
  <option value="30">30</option>
  <option value="31">31</option>
</select>

<select id="Birthday_Month" name="Birthday_Month">
<option value="-1">Month:</option>
<option value="January">Jan</option>
<option value="February">Feb</option>
<option value="March">Mar</option>
<option value="April">Apr</option>
<option value="May">May</option>
<option value="June">Jun</option>
<option value="July">Jul</option>
<option value="August">Aug</option>
<option value="September">Sep</option>
<option value="October">Oct</option>
<option value="November">Nov</option>
<option value="December">Dec</option>
</select>
 
<select name="Birthday_Year" id="Birthday_Year">
 
<option value="-1">Year:</option>


<option value="2010">2018</option>
<option value="2009">2017</option>
<option value="2008">2016</option>
<option value="2007">2015</option>
<option value="2012">2014</option>
<option value="2011">2013</option>
<option value="2012">2012</option>
<option value="2011">2011</option>
<option value="2010">2010</option>
<option value="2009">2009</option>
<option value="2008">2008</option>
<option value="2007">2007</option>
<option value="2006">2006</option>
<option value="2005">2005</option>
<option value="2004">2004</option>
<option value="2003">2003</option>
<option value="2002">2002</option>
<option value="2001">2001</option>
<option value="2000">2000</option>
 
<option value="1999">1999</option>
<option value="1998">1998</option>
<option value="1997">1997</option>
<option value="1996">1996</option>
<option value="1995">1995</option>
<option value="1994">1994</option>
<option value="1993">1993</option>
<option value="1992">1992</option>
<option value="1991">1991</option>
<option value="1990">1990</option>
 
<option value="1989">1989</option>
<option value="1988">1988</option>
<option value="1987">1987</option>
<option value="1986">1986</option>
<option value="1985">1985</option>
<option value="1984">1984</option>
<option value="1983">1983</option>
<option value="1982">1982</option>
<option value="1981">1981</option>
<option value="1980">1980</option>
</select></label>
                          <span class="style3">*</span></p>
                        <p>
                          <label>
                          <input type="submit" name="Submit" value="Submit" class="styled-button"/>
                          </label>
                        </p>
            </form>            <p>&nbsp;   </p></td>
            <td></td>
        </tr>
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        <tr>
          <td height="312"></td>
          <td rowspan="2" valign="top"><p>&nbsp;</p>
            <p class="style2">First name</p>
            <p class="style2">Last name</p>
            <p class="style2">Address</p>
            <p class="style2">
                <label></label>
            Next of Kin          </p>            
            <p class="style2">Date</p></td>
            <td></td>
            <td></td>
        </tr>
        <tr>
          <td height="4"></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
        </tr>
      </table>
      </div>
        <div class="clr"></div>
    </div>
      <div class="clr"></div>
  </div>
</div>
<div class="footer">
    <div class="footer_resize">
      <p class="lf">&copy; Copyright</p>
      <div style="clear:both;"></div>
    </div>
</div>
</div>
</body>
</html>
